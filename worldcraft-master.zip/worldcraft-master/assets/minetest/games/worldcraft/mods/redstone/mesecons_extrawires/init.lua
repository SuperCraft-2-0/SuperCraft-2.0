-- dofile(minetest.get_modpath("mesecons_extrawires").."/crossing.lua");
-- The crossing code is not active right now because it is hard to maintain
dofile(minetest.get_modpath("mesecons_extrawires").."/mesewire.lua");
