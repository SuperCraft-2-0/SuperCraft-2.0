#!/bin/bash
ndk-build NDEBUG=1
ant debug
